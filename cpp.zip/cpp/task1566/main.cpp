// Online C++ compiler to run C++ program online
#include <iostream>

int main() {
    int a; //число элементов массива
    std::cin >> a;
    int ar[a];
    int arfin[a];//результирующий массив
//заполнили массив
    for (int i=0; i<a; i++)
    {
        std::cin >> ar[i] ;
    }
//будем искать минимум и максимум
    int min = ar[0];
    int max = ar[0];
    int s = 0;
    int t = 0;

    for(int i = 0; i < a; i++)
{
    if(ar[i] < min)
    {
   	 min = ar[i];
   	 s=i;//запоминаем позицию минимального элемента
    }

    if(ar[i] > max)
    {
   	 max = ar[i];
   	 t = i;//запоминаем позицию максимального элемента
    }
}
   //меняем местами макс и мин
   int r=ar[s];
   ar[s]=ar[t];
   ar[t]=r;
    for(int i = 0; i <a; i++) //печатаем в цикле массив
    {
     std::cout << ar[i]<< " "; 
    }
    return 0;
}