// Online C++ compiler to run C++ program online
#include <iostream>

int main() {
    int a0{0}; //для цикла
    int a;
    int ar[9]{0,0,0,0,0,0,0,0,0};//счетчики цифр
    while (a0 <= 0)
      {
        std::cin >> a;
        if (a==0)
        {
          a0++;
        }
        if (a==1)
        {
          ar[0]=ar[0]+1;
        }
        if (a==2)
        {
          ar[1]=ar[1]+1;
        }
        if (a==3)
        {
          ar[2]=ar[2]+1;
        }
        if (a==4)
        {
          ar[3]=ar[3]+1;
        }
        if (a==5)
        {
          ar[4]=ar[4]+1;
        }
        if (a==6)
        {
          ar[5]=ar[5]+1;
        }
        if (a==7)
        {
          ar[6]=ar[6]+1;
        }
        if (a==8)
        {
          ar[7]=ar[7]+1;
        }
        if (a==9)
        {
          ar[8]=ar[8]+1;
        }
      }
    for (int i=0;i<=8; i++)
    {
      std::cout << ar[i]<<" ";
    }
    return 0;
}