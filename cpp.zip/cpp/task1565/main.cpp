// Online C++ compiler to run C++ program online
#include <iostream>

int main() {
    int a; //число элементов массива
    std::cin >> a;
    int ar[a];
//заполнили массив
    for (int i=0; i<a; i++)
    {
        std::cin >> ar[i] ;
    }
//правый элемент массива сохранили во временную переменную tmp
    int tmp = ar[a-1];
//передвигаем все элементы массива вправо, идем от последнего влево 
    for (int i = a-1; i>0; i--)
    {
        ar[i] = ar[i-1];
    }
//на нулевое место ставим сохраненное во временную переменную число
    ar[0]=tmp;
   
    for(int i = 0; i <a; i++) //печатаем в цикле массив
    {
     std::cout << ar[i]<< " "; 
    }
    return 0;
}