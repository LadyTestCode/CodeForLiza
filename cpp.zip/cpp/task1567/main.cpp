// Online C++ compiler to run C++ program online
#include <iostream>

int main() {
    int a; //число элементов массива
    std::cin >> a;
    int ar[a];
   
//заполнили массив
    for (int i=0; i<a; i++)
    {
        std::cin >> ar[i] ;
    }
//проходим по элементам массива кроме крайних
    for (int i = 1; i < a-1; i++)
    {
        if (ar[i] == ar[i-1] + ar[i+1])
        {
          std::cout << ar[i]<< " ";
            
        }
    }
 
    return 0;
}