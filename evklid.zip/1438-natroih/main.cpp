#include <iostream>
#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
#include <cstdlib>
#include <string>

//главная функция
int main() {
   std::string c;
   int b=0;
   std::string s = "";
   std::cin >> s;
   int k;
   for (int i=0;i<s.length();i++)
     {
       c=s[i];
       k=std::stoi(c);
       b = b + k;
     }
if (b%3==0)
  std::cout << "YES";
else 
  std::cout << "NO";
  return 0;
}