#include <iostream>
#include <math.h>

//главная функция
int main ()
{
  int a;
  bool flag = false;
  std::cin >> a;
  for (int i=2; i <= sqrt(a); i++)
    {
      if (a%i==0)
      {
        flag = true;
      }
    }
  if (flag == true) std::cout << "composite";
  else std::cout << "prime";
  return 0;
}