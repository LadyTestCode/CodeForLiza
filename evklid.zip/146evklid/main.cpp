#include <iostream>
//алгоритм Евклида. Вычитание
int NOD(int x, int y)
{
  while (x!=y)
  if (x>y)
    x-=y;
  else y-=x;
return x;
}

//главная функция
int main ()
{
  int a,b,c,d,m,n;
  std::cin >> a;
  std::cin >> b;
  std::cin >> c;
  std::cin >> d;
  if (b==0 or d==0)
  {
    std::cout << "Error";
    return 0;
  }
//находим числитель и знаменатель дроби суммы
  m=a*d+b*c;
  n=b*d;
//вызываем функцию поиска НОД
  int q = NOD(m, n);
  m=m/q;
  n=n/q;
  std::cout << m << " " << n << std::endl;
return 0;
  }