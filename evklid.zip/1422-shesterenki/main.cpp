#include <iostream>
#include <string>

//главная функция
int main() {
  int a,b;
  std::cin >> a;
  std::cin >> b;
  int max = 0;
  int min = 0;
  if (a>=b) 
  {
    max = a;
    min = b;
  }
  else 
  {
    max = b;
    min = a;
  }
  int max1=max;
  int i=1;
  while (max1%min != 0)
    {
        i++;
        max1=max*i;
    }
  std::cout << max1;
  return 0;
}