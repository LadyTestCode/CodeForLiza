// Online C++ compiler to run C++ program online
#include <iostream>

int main() {
    int a; //число элементов массива
    std::cin >> a;
    int ar[a];
   
//заполнили массив
    for (int j=0; j<a; j++)
    {
      std::cin >> ar[j] ;
    }

    bool flag{false};
    
    for (int i = 0; i < a; i++)
    {
      flag=false;
      for (int k = 0; k < a; k++)
      {
        if ((ar[k]==ar[i]) and (i != k))
          flag = true;
                
      }
      if (flag == false)
      {
        std::cout <<ar[i]<<" ";
      }
    }
   
      return 0;
}