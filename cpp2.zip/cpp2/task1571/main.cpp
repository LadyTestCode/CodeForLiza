// Online C++ compiler to run C++ program online
#include <iostream>

int main() {
    int a; //число элементов массива
    std::cin >> a;
    int ar[a];
//заполнили массив
    for (int i=0; i<a; i++)
    {
        std::cin >> ar[i] ;
    }
//будем искать 2 максимума и 2 минимума
    int max = ar[0];
    int max1 = ar[0];
    int min = ar[0];
    int min1 = ar[0];
    int t = 0;
    int t1 = 0;

  
//поиск макс среди положительных и минимальных среди отрицательных
    for(int i = 0; i < a; i++)
    {
      if (ar[i] >0)
      {
        if(ar[i] > max)
        {
       	 max = ar[i];
       	 t = i;//запоминаем позицию максимального элемента
        }
      }
      if (ar[i] <0)
      {
         if(ar[i] < min)
        {
       	 min = ar[i];
       	 t1 = i;//запоминаем позицию максимального элемента
        }
      }
    }
    ar[t]=0;
    ar[t1]=0;
  
    for(int i = 0; i < a; i++)
      {
        if (ar[i] >0)
        {
          if(ar[i] > max1)
          {
         	 max1 = ar[i];
          }
        }
        if (ar[i] <0)
        {
          if(ar[i] < min1)
          {
         	 min1 = ar[i];
          }
        }
      }
 //итого у нас есть 2 отрицательных и 2 положительных числа максимальные по модулю
//сравним их произведения
    if (min1*min>max*max1)
    {
      std::cout<<min<<" "<<min1;
    }
    else
    {
       std::cout<<max1<<" "<<max;
    }
    
    return 0;
}